# Introduction to R for Statistical Analysis

# Set default working directory
# CTRL-L - clear console screen

# Perform some simple calculation
4 + 6
(3 + 5)^2/(17 + 21)

# Create objects
height <- 1.67
weight <- 66
BMI <- weight / height^2
print(BMI)

# Show and remove objects
ls()
rm(height)
rm(list = ls())

# Data types
x <- "hello world"; typeof(x)
y <-  12.5; typeof(y)
z <- 5L; typeof(z)
3 > 2 

# Data structure - Vector (same data type)
v <- c(1, 2, 3, 4, 5, 6)
print(v)
v <- c(1:6)
v <- c("apple", "banana", "cat")
print(v)
v[3]

# Data structure - Matrix (same data type)
m <- matrix(seq(5,100,5), nrow=5)
print(m)
m[1,2]

m <- matrix(seq(5,100,5), nrow=5, byrow=TRUE)
print(m)
m[1,2]

# Data Frame (mixed data type arranged by rows and columns)
# Example 1
height <- c(1.88, 1.83, 1.63, 1.78)
weight <- c(74.84, 83.91, 61.23, 65.77)
BMI <- c(weight / height^2)
df <- data.frame(height, weight, BMI)
print(df)
df[1,2]

# Example 2
class_num <- c(1, 2, 3, 4)
name <- c("Peter", "Mary", "Ann", "John")
score <- c(60, 70, 80, 90)
df <- data.frame(class_num, name, score)
print(df)
df[1,2]

# List (collection of different type of objects)
v <- c("apple", "banana", "cat")
m <- matrix(seq(5,100,5), nrow=5)
l <- list(vector=v, matrix=m)
print(l)
l$vector[1]
l$matrix[1,1]

# R Programming
# If-statement
x <- 20
y <- 10
if (x > y) print("Yes") else print("No")

# For-loop
for (z in 1:5) { print(z) }

# Function
BMI <- function (weight, height) { result <- weight / height^2; return (result)}
BMI(66,1.67)

# Import data from a .csv file
data1 <- read.csv(file.choose(), header = TRUE) # sample-csv-dataset.csv
data1
summary(data1)

# Import data from Excel file
# requires readxl package
# install.packages("readxl")
# library(readxl)
data2 <- read_excel(file.choose()) # sample-xlsx-dataset.xlsx
data2

# Calculating the Mean
data1 <- read.csv(file.choose(), header = TRUE) # sample-csv-dataset.csv  
data1
sum(data1$Test1) / length(data1$Test1) # sample size
mean(data1$Test1)

# Calculating the Median
sort(data1$Test1) # sort data from smallest to largest
median(data1$Test1)

# Calculating the Mode
mode(data1$Test1) # returns the type of object
summary(as.factor(data1$Test1))

# Calculating the Range
range(data1$Test1) #returns the min and max value 
max(data1$Test1) - min(data1$Test1)

# Calculating the Sample Variance
var(data1$Test1)

# Calculating the Sample Standard Deviation
sd(data1$Test1)

# Use describe in the psych package to show all descriptive statistics
#install.packages("psych")
#library(psych)
describe(data1$Test1)

# Histogram
hist(data1$Test1, xlab = "Scores", main = "Reading")

# Boxplot
boxplot(data1$Test1, main = "Reading", xlab = "Test1", ylab = "Scores")

# Scatter Plot
plot(data1$Test1, main = "Reading", xlab = "Test1", ylab = "Scores")

# Line Chart
plot(data1$Test1, main = "Reading", xlab = "Test1", ylab = "Scores", type="l")
plot(data1$Test1, main = "Reading", xlab = "Test1", ylab = "Scores", type="b")

# Pie Chart
Test1_avg <- mean(data1$Test1)
Test2_avg <- mean(data1$Test2)
avg_scores <- c(Test1_avg, Test2_avg)
labels <- c("Test1", "Test2")
pie(avg_scores, labels = paste0(labels, " (", avg_scores, ")"), main = "Average Scores")






